class ValidationException(Exception):
    pass
