from poly_eip712_structs.domain_separator import make_domain
from poly_eip712_structs.struct import EIP712Struct
from poly_eip712_structs.types import Address, Array, Boolean, Bytes, Int, String, Uint

default_domain = None
